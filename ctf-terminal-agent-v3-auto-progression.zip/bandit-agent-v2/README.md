# CTF Terminal Agent — Qwen/Ollama

A general SSH terminal CTF agent whose planning brain is Qwen 2.5 7B through Ollama.

The Python controller does **not** contain a Bandit solution database. Qwen receives
terminal observations, failed attempts, hypotheses and command history, then chooses
the next command.

## Architecture

```text
current SSH account
       │
       ▼
 observe terminal
       │
       ▼
 Qwen 2.5 7B
 (hypothesis + next command)
       │
       ▼
 execute one command
       │
       ▼
 output / error / evidence
       │
       └───────────────┐
                       ▼
               candidate credential
                       │
                       ▼
             real SSH verification
                       │
                 accepted?
                  /       \
                no         yes
                │           │
                └─replan    ▼
                       next Bandit user
                            │
                            └──► repeat
```

## Setup

### Windows PowerShell

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```

Start Ollama:

```powershell
ollama serve
ollama pull qwen2.5:7b
```

Start the dashboard in another terminal:

```powershell
python app.py web
```

Open:

```text
http://127.0.0.1:8787
```

## Automatic Bandit progression

The new runner supports:

```bash
python app.py run --start-level 1 --end-level 33

The final requested level does not require a `bandit34` account; the controller stops at the requested `--end-level`.
```

For this to work, the starting account must already be authenticated.

For example, set `.env`:

```env
CTF_USER=bandit1
CTF_PASSWORD=<the currently valid bandit1 password>
```

Then:

```bash
python app.py run --start-level 1 --end-level 33

The final requested level does not require a `bandit34` account; the controller stops at the requested `--end-level`.
```

You can also supply the starting password without putting it in `.env`:

```bash
python app.py run \
  --start-level 1 \
  --end-level 33 \
  --password-file bandit1-password.txt
```

The controller then:

1. logs into `bandit1`;
2. asks Qwen what to inspect/do;
3. executes Qwen's commands;
4. remembers observations and failed commands;
5. detects possible credentials;
6. verifies each candidate by attempting SSH as `bandit2`;
7. if verification succeeds, switches to `bandit2`;
8. repeats for `bandit3`, `bandit4`, etc.;
9. explores the final requested level.

The controller does **not** write the discovered passwords into the event log.

### Important

`--start-level 1` does not magically recover the Bandit 1 password. You must provide
valid starting credentials through `.env`, `--password`, or `--password-file`.

The agent learns the *next* credential through terminal exploration and verifies it
against the next SSH account.

## Single-level / general CTF mode

Without level arguments, the agent can operate against a generic configured SSH target:

```bash
python app.py run --user ctfuser --password 'starting-password'
```

A one-off verification target is still supported:

```bash
python app.py run --verify-user ctf-next
```

## Dashboard

The dashboard exposes:

- current user and level
- progression state
- current Qwen analysis
- hypothesis
- command being executed
- latest terminal output
- candidate credential status
- event stream
- level transitions

## Safety / scope

The SSH executor connects only to the configured CTF host and port.

The command policy blocks several obviously destructive commands. It is not a
complete shell sandbox. Use this only against systems you are authorized to test,
such as your CTF environment.

## What is deliberately not hardcoded

There is no table like:

```text
level 1 -> cat ./-
level 2 -> ...
level 3 -> ...
```

The agent is expected to discover the environment from command output.

The progression controller knows only the generic Bandit naming convention:

```text
banditN -> banditN+1
```

It does not know the solution to any level.

## Known limitation

Qwen 7B can still make poor hypotheses or waste steps. The controller mitigates
this with command-history memory, duplicate-command rejection, failure context,
candidate verification, and automatic level transitions, but it cannot guarantee
that the model will solve every challenge.
